//
//  lol.cpp
//  CS 3113 Project 5
//
//  Created by Sahil on 11/23/24.
//


/**
* Author: Sahil Singh
* Assignment: Platformer
* Date due: 2023-11-23, 11:59pm
* I pledge that I have completed this assignment without
* collaborating with anyone else, in conformance with the
* NYU School of Engineering Policies and Procedures on
* Academic Misconduct.
**/